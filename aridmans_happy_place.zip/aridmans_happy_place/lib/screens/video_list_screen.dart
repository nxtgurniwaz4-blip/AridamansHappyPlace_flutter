import 'package:flutter/material.dart';

import '../models/learning_category.dart';
import '../services/youtube_service.dart';
import '../widgets/learn_widgets.dart';

/// Port of `VideoListView`.
class VideoListScreen extends StatefulWidget {
  const VideoListScreen({super.key, required this.category});

  final LearningCategory category;

  @override
  State<VideoListScreen> createState() => _VideoListScreenState();
}

class _VideoListScreenState extends State<VideoListScreen> {
  List<YouTubeVideo> _videos = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final videos = await YouTubeService.instance.search(widget.category);
      if (!mounted) return;
      setState(() => _videos = videos);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _videos = const [];
        _error = e.toString();
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _play(YouTubeVideo video) {
    final height = MediaQuery.of(context).size.height * 0.92;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => SizedBox(
        height: height,
        child: InlineVideoPlayerSheet(video: video),
      ),
    );
  }

  Widget _message(IconData icon, String title, String? description) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            if (description != null) ...[
              const SizedBox(height: 8),
              Text(description, textAlign: TextAlign.center),
            ],
            const SizedBox(height: 16),
            OutlinedButton(onPressed: _load, child: const Text('Try again')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_loading) {
      body = const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [CircularProgressIndicator(), SizedBox(height: 12), Text('Finding videos…')],
        ),
      );
    } else if (_error != null) {
      body = _message(Icons.warning_amber_rounded, "Couldn't load videos", _error);
    } else if (_videos.isEmpty) {
      body = _message(Icons.play_circle_outline, 'No videos found', 'Try again later.');
    } else {
      body = ListView.builder(
        itemCount: _videos.length,
        itemBuilder: (context, i) {
          final video = _videos[i];
          return InkWell(
            onTap: () => _play(video),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: SizedBox(
                      width: 120,
                      height: 68,
                      child: video.thumbnailUrl == null
                          ? const _ThumbPlaceholder()
                          : Image.network(
                              video.thumbnailUrl!,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const _ThumbPlaceholder(),
                              loadingBuilder: (_, child, progress) =>
                                  progress == null ? child : const _ThumbPlaceholder(),
                            ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          video.title,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          video.channelTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: Theme.of(context).colorScheme.onSurfaceVariant,
                              ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.category.title)),
      body: body,
    );
  }
}

class _ThumbPlaceholder extends StatelessWidget {
  const _ThumbPlaceholder();

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: const Center(child: Icon(Icons.play_arrow, color: Colors.grey)),
    );
  }
}

/// Port of `InlineVideoPlayerSheet`. Side-by-side (65/35) on tablets,
/// stacked on phones.
class InlineVideoPlayerSheet extends StatelessWidget {
  const InlineVideoPlayerSheet({super.key, required this.video});

  final YouTubeVideo video;

  static const _blurb =
      "Enjoy learning with Pramod's Life! Close this window to go back to the list.";

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final main = SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            color: Colors.black,
            child: YouTubePlayerBox(videoId: video.id, autoPlay: true),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  video.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  video.channelTitle,
                  style: textTheme.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
                ),
              ],
            ),
          ),
        ],
      ),
    );

    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 700;

        if (wide) {
          return Row(
            children: [
              Expanded(flex: 65, child: main),
              VerticalDivider(width: 1, color: scheme.outlineVariant),
              Expanded(
                flex: 35,
                child: ColoredBox(
                  color: scheme.surfaceContainer,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                'Video Details',
                                style: textTheme.titleMedium
                                    ?.copyWith(fontWeight: FontWeight.bold),
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.cancel),
                              onPressed: () => Navigator.of(context).pop(),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Text(
                          _blurb,
                          style: textTheme.bodyMedium
                              ?.copyWith(color: scheme.onSurfaceVariant),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        }

        return Column(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: IconButton(
                icon: const Icon(Icons.cancel),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
            Expanded(child: main),
          ],
        );
      },
    );
  }
}
