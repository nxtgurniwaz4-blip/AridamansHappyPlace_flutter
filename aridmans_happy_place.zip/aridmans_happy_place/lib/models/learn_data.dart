// Port of LearnItem / LearnData / AlphabetEntry / Alphabet from LearnViews.swift.
//
// PHOTOS: each item loads a photo from Wikipedia automatically. To use your own,
// add a PNG to assets/learn/ named "learn_" + lowercase name with underscores,
// e.g. learn_apple.png, learn_sweet_potato.png.
// VIDEOS: loaded from YouTube with your API key. To force a specific video, set
// youtubeId (the part after v= in the link).

class LearnItem {
  const LearnItem(this.name, {this.imageUrl, this.youtubeId});

  final String name;
  final String? imageUrl;
  final String? youtubeId;

  String get slug => name.toLowerCase().replaceAll(' ', '_');
  String get assetPath => 'assets/learn/learn_$slug.png';

  /// Wikipedia article whose lead photo is used when no photo is bundled.
  static const Map<String, String> _wikiOverrides = {
    'Orange': 'Orange (fruit)',
    'Grapes': 'Grape',
    'Kiwi': 'Kiwifruit',
    'Corn': 'Maize',
    'Blueberries': 'Blueberry',
    'Bell Pepper': 'Bell pepper',
    'Chili Pepper': 'Chili pepper',
    'Sweet Potato': 'Sweet potato',
    'Ice Cream': 'Ice cream',
    'Yoyo': 'Yo-yo',
    'Juice': 'Juice',
  };

  String get wikiTitle => _wikiOverrides[name] ?? name;
}

class LearnData {
  static const countingQuery = 'counting 1 to 20 for toddlers';
  static const String? countingYouTubeId = null;

  static const fruits = <LearnItem>[
    LearnItem('Apple'), LearnItem('Banana'), LearnItem('Orange'),
    LearnItem('Grapes'), LearnItem('Strawberry'), LearnItem('Watermelon'),
    LearnItem('Pineapple'), LearnItem('Cherry'), LearnItem('Mango'),
    LearnItem('Pear'), LearnItem('Peach'), LearnItem('Lemon'),
    LearnItem('Kiwi'), LearnItem('Coconut'), LearnItem('Blueberries'),
  ];

  static const vegetables = <LearnItem>[
    LearnItem('Carrot'), LearnItem('Broccoli'), LearnItem('Tomato'),
    LearnItem('Potato'), LearnItem('Corn'), LearnItem('Cucumber'),
    LearnItem('Onion'), LearnItem('Garlic'), LearnItem('Bell Pepper'),
    LearnItem('Eggplant'), LearnItem('Lettuce'), LearnItem('Sweet Potato'),
    LearnItem('Chili Pepper'),
  ];
}

class AlphabetEntry {
  const AlphabetEntry(this.letter, this.spoken, this.word);

  final String letter;

  /// How the voice says the letter's name.
  final String spoken;
  final String word;

  LearnItem get item => LearnItem(word);
  String get sentence => '$spoken. $spoken is for $word.';
}

class Alphabet {
  static const all = <AlphabetEntry>[
    AlphabetEntry('A', 'ay', 'Apple'),
    AlphabetEntry('B', 'bee', 'Ball'),
    AlphabetEntry('C', 'see', 'Cat'),
    AlphabetEntry('D', 'dee', 'Dog'),
    AlphabetEntry('E', 'ee', 'Elephant'),
    AlphabetEntry('F', 'eff', 'Fish'),
    AlphabetEntry('G', 'gee', 'Grapes'),
    AlphabetEntry('H', 'aitch', 'Horse'),
    AlphabetEntry('I', 'eye', 'Ice Cream'),
    AlphabetEntry('J', 'jay', 'Juice'),
    AlphabetEntry('K', 'kay', 'Kite'),
    AlphabetEntry('L', 'el', 'Lion'),
    AlphabetEntry('M', 'em', 'Mango'),
    AlphabetEntry('N', 'en', 'Nest'),
    AlphabetEntry('O', 'oh', 'Orange'),
    AlphabetEntry('P', 'pee', 'Pineapple'),
    AlphabetEntry('Q', 'cue', 'Quail'),
    AlphabetEntry('R', 'ar', 'Rabbit'),
    AlphabetEntry('S', 'es', 'Strawberry'),
    AlphabetEntry('T', 'tee', 'Tomato'),
    AlphabetEntry('U', 'you', 'Umbrella'),
    AlphabetEntry('V', 'vee', 'Violin'),
    AlphabetEntry('W', 'double you', 'Watermelon'),
    AlphabetEntry('X', 'ex', 'Xylophone'),
    AlphabetEntry('Y', 'why', 'Yoyo'),
    AlphabetEntry('Z', 'zee', 'Zebra'),
  ];
}
