import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import '../models/learn_data.dart';
import '../services/wikipedia_photo.dart';
import '../services/youtube_service.dart';

/// Port of `LearnPhoto`: a square photo. Uses a bundled asset if present,
/// otherwise an explicit imageUrl, otherwise the Wikipedia lead photo.
class LearnPhoto extends StatefulWidget {
  const LearnPhoto({super.key, required this.item, this.corner = 16});

  final LearnItem item;
  final double corner;

  @override
  State<LearnPhoto> createState() => _LearnPhotoState();
}

class _LearnPhotoState extends State<LearnPhoto> {
  String? _url;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _resolve();
  }

  @override
  void didUpdateWidget(covariant LearnPhoto oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.item.name != widget.item.name) {
      _url = null;
      _failed = false;
      _resolve();
    }
  }

  Future<void> _resolve() async {
    final name = widget.item.name;
    final explicit = widget.item.imageUrl;
    final url = explicit ?? await WikipediaPhoto.url(widget.item.wikiTitle);
    if (!mounted || name != widget.item.name) return;
    setState(() {
      _url = url;
      _failed = url == null;
    });
  }

  Widget get _placeholder => const Center(
        child: Icon(Icons.photo_outlined, size: 40, color: Colors.grey),
      );

  Widget get _remote {
    if (_url != null) {
      return Image.network(
        _url!,
        fit: BoxFit.cover,
        loadingBuilder: (context, child, progress) => progress == null
            ? child
            : const Center(child: CircularProgressIndicator()),
        errorBuilder: (context, error, stack) => _placeholder,
      );
    }
    return _failed ? _placeholder : const Center(child: CircularProgressIndicator());
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(widget.corner),
        child: ColoredBox(
          color: Colors.grey.withValues(alpha: 0.12),
          child: Image.asset(
            widget.item.assetPath,
            fit: BoxFit.cover,
            width: double.infinity,
            height: double.infinity,
            // No bundled photo: fall back to the network photo.
            errorBuilder: (context, error, stack) => _remote,
          ),
        ),
      ),
    );
  }
}

/// Port of `YouTubePlayer` / `YouTubeInlinePlayerView` (WKWebView iframe).
class YouTubePlayerBox extends StatefulWidget {
  const YouTubePlayerBox({super.key, required this.videoId, this.autoPlay = false});

  final String videoId;
  final bool autoPlay;

  @override
  State<YouTubePlayerBox> createState() => _YouTubePlayerBoxState();
}

class _YouTubePlayerBoxState extends State<YouTubePlayerBox> {
  late final YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController.fromVideoId(
      videoId: widget.videoId,
      autoPlay: widget.autoPlay,
      params: const YoutubePlayerParams(
        showFullscreenButton: true,
        strictRelatedVideos: true, // rel=0
        // FIX for "Error 152-4" / "Error 153": YouTube now rejects embeds whose
        // page origin is youtube.com (the youtube_player_iframe 5.x default).
        // On 5.x this must be a real YouTube host, not the app id.
        origin: 'https://www.youtube-nocookie.com',
      ),
    );
  }

  @override
  void didUpdateWidget(covariant YouTubePlayerBox oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.videoId != widget.videoId) {
      _controller.loadVideoById(videoId: widget.videoId);
    }
  }

  @override
  void dispose() {
    _controller.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return YoutubePlayer(controller: _controller, aspectRatio: 16 / 9);
  }
}

/// Port of `RemoteVideoView`: shows a video for a search phrase (or a known
/// video id), with a clear message if it fails.
class RemoteVideoView extends StatefulWidget {
  const RemoteVideoView({super.key, required this.query, this.knownId});

  final String query;
  final String? knownId;

  @override
  State<RemoteVideoView> createState() => _RemoteVideoViewState();
}

class _RemoteVideoViewState extends State<RemoteVideoView> {
  String? _videoId;
  String? _message;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (widget.knownId != null) {
      setState(() => _videoId = widget.knownId);
      return;
    }
    try {
      final id = await YouTubeService.instance.firstVideoId(widget.query);
      if (mounted) setState(() => _videoId = id);
    } catch (e) {
      if (mounted) setState(() => _message = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final id = _videoId;
    Widget child;
    if (id != null) {
      child = Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: YouTubePlayerBox(videoId: id),
          ),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: () => launchUrl(
              Uri.parse('https://www.youtube.com/watch?v=$id'),
              mode: LaunchMode.externalApplication,
            ),
            icon: const Icon(Icons.open_in_new),
            label: const Text(
              'Open in YouTube',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      );
    } else if (_message != null) {
      child = Text(
        _message!,
        textAlign: TextAlign.center,
        style: Theme.of(context).textTheme.bodySmall,
      );
    } else {
      child = const Padding(
        padding: EdgeInsets.all(24),
        child: CircularProgressIndicator(),
      );
    }
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Center(child: child),
    );
  }
}