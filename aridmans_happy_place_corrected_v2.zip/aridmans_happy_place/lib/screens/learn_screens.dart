import 'package:flutter/material.dart';

import '../models/learn_data.dart';
import '../services/speaker.dart';
import '../widgets/learn_widgets.dart';

/// Waits for speech to finish, but never hangs if the engine forgets to report.
Future<void> _sayAndWait(String text) => LearnSpeaker.instance
    .say(text)
    .timeout(const Duration(seconds: 4), onTimeout: () {});

TextStyle _big(double size, {Color? color}) =>
    TextStyle(fontSize: size, fontWeight: FontWeight.w800, color: color);

Widget _pillButton({
  required VoidCallback? onPressed,
  required IconData icon,
  required String label,
  required Color color,
}) {
  return FilledButton.icon(
    onPressed: onPressed,
    icon: Icon(icon),
    label: Text(label, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    style: FilledButton.styleFrom(
      backgroundColor: color,
      foregroundColor: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
      shape: const StadiumBorder(),
    ),
  );
}

// ---------------------------------------------------------------- Hub

/// Port of `LearnHubView`.
class LearnHubScreen extends StatelessWidget {
  const LearnHubScreen({super.key});

  void _open(BuildContext context, Widget page) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Learn')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _HubCard(
            icon: Icons.abc,
            title: 'ABC',
            color: Colors.purple,
            onTap: () => _open(context, const AlphabetScreen()),
          ),
          _HubCard(
            icon: Icons.numbers,
            title: 'Counting',
            color: Colors.orange,
            onTap: () => _open(context, const CountingScreen()),
          ),
          _HubCard(
            icon: Icons.apple,
            title: 'Fruits',
            color: Colors.red,
            onTap: () => _open(
              context,
              const NameListScreen(
                title: 'Fruits',
                items: LearnData.fruits,
                color: Colors.red,
              ),
            ),
          ),
          _HubCard(
            icon: Icons.eco,
            title: 'Vegetables',
            color: Colors.green,
            onTap: () => _open(
              context,
              const NameListScreen(
                title: 'Vegetables',
                items: LearnData.vegetables,
                color: Colors.green,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HubCard extends StatelessWidget {
  const _HubCard({
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Material(
        color: color.withValues(alpha: 0.2),
        borderRadius: BorderRadius.circular(24),
        child: InkWell(
          borderRadius: BorderRadius.circular(24),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                SizedBox(width: 60, child: Icon(icon, size: 40, color: color)),
                const SizedBox(width: 16),
                Text(title, style: _big(30)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ----------------------------------------------------------- Alphabet

/// Port of `AlphabetView`.
class AlphabetScreen extends StatefulWidget {
  const AlphabetScreen({super.key});

  @override
  State<AlphabetScreen> createState() => _AlphabetScreenState();
}

class _AlphabetScreenState extends State<AlphabetScreen> {
  bool _playing = false;
  bool _cancelled = false;
  String? _highlighted;

  @override
  void dispose() {
    _cancelled = true;
    LearnSpeaker.instance.stop();
    super.dispose();
  }

  Future<void> _playAll() async {
    if (_playing) return;
    setState(() => _playing = true);
    for (final entry in Alphabet.all) {
      if (!mounted || _cancelled) break;
      setState(() => _highlighted = entry.letter);
      await _sayAndWait(entry.spoken);
      await Future<void>.delayed(const Duration(milliseconds: 300));
    }
    if (mounted) {
      setState(() {
        _highlighted = null;
        _playing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ABC')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _playing ? null : _playAll,
                icon: const Icon(Icons.play_circle_fill),
                label: Text(
                  _playing ? 'Saying the ABCs...' : 'Say the ABCs',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                ),
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.purple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
            const SizedBox(height: 16),
            GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 100,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
              ),
              itemCount: Alphabet.all.length,
              itemBuilder: (context, i) {
                final entry = Alphabet.all[i];
                final on = _highlighted == entry.letter;
                return AnimatedScale(
                  scale: on ? 1.15 : 1,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOutBack,
                  child: Material(
                    color: Colors.purple.withValues(alpha: on ? 0.6 : 0.15),
                    borderRadius: BorderRadius.circular(18),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(18),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => LetterDetailScreen(entry: entry)),
                      ),
                      child: Center(child: Text(entry.letter, style: _big(44))),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

/// Port of `LetterDetailView`.
class LetterDetailScreen extends StatefulWidget {
  const LetterDetailScreen({super.key, required this.entry});

  final AlphabetEntry entry;

  @override
  State<LetterDetailScreen> createState() => _LetterDetailScreenState();
}

class _LetterDetailScreenState extends State<LetterDetailScreen> {
  @override
  void initState() {
    super.initState();
    _speak();
  }

  @override
  void dispose() {
    LearnSpeaker.instance.stop();
    super.dispose();
  }

  void _speak() => LearnSpeaker.instance.say(widget.entry.sentence);

  @override
  Widget build(BuildContext context) {
    final entry = widget.entry;
    return Scaffold(
      appBar: AppBar(title: Text(entry.letter)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Center(
          child: Column(
            children: [
              Text(
                '${entry.letter}${entry.letter.toLowerCase()}',
                style: _big(130, color: Colors.purple),
              ),
              const SizedBox(height: 20),
              ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 320),
                child: LearnPhoto(item: entry.item, corner: 28),
              ),
              const SizedBox(height: 20),
              Text(
                '${entry.letter} is for ${entry.word}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              _pillButton(
                onPressed: _speak,
                icon: Icons.volume_up,
                label: 'Say it',
                color: Colors.purple,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ----------------------------------------------------------- Counting

/// Port of `CountingView`.
class CountingScreen extends StatefulWidget {
  const CountingScreen({super.key});

  @override
  State<CountingScreen> createState() => _CountingScreenState();
}

class _CountingScreenState extends State<CountingScreen> {
  static const _maxNumber = 20;
  // One fruit per number, so kids count identical things.
  static const _countingFruits = ['Apple', 'Orange', 'Strawberry', 'Lemon', 'Pear'];

  int _number = 1;
  int _highlighted = 0;
  bool _counting = false;
  bool _cancelled = false;

  LearnItem get _item => LearnItem(_countingFruits[(_number - 1) % _countingFruits.length]);

  @override
  void initState() {
    super.initState();
    LearnSpeaker.instance.say(LearnSpeaker.numberWords[_number]);
  }

  @override
  void dispose() {
    _cancelled = true;
    LearnSpeaker.instance.stop();
    super.dispose();
  }

  void _change(int delta) {
    setState(() {
      _number = (_number + delta).clamp(1, _maxNumber);
      _highlighted = 0;
    });
    LearnSpeaker.instance.say(LearnSpeaker.numberWords[_number]);
  }

  Future<void> _countAloud() async {
    if (_counting) return;
    setState(() => _counting = true);
    final target = _number;
    for (var i = 1; i <= target; i++) {
      if (!mounted || _cancelled) break;
      setState(() => _highlighted = i);
      await _sayAndWait(LearnSpeaker.numberWords[i]);
      await Future<void>.delayed(const Duration(milliseconds: 200));
    }
    if (mounted) {
      setState(() {
        _highlighted = 0;
        _counting = false;
      });
    }
  }

  void _showVideo() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => const SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 24),
          child: RemoteVideoView(
            query: LearnData.countingQuery,
            knownId: LearnData.countingYouTubeId,
          ),
        ),
      ),
    );
  }

  Widget _stepButton(IconData icon, bool enabled, VoidCallback onTap) {
    return Expanded(
      child: FilledButton.tonal(
        onPressed: enabled && !_counting ? onTap : null,
        style: FilledButton.styleFrom(
          backgroundColor: Colors.orange.withValues(alpha: 0.2),
          foregroundColor: Colors.orange.shade900,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        child: Icon(icon, size: 28),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = _item;
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          children: [
            Text('$_number', style: _big(100, color: Colors.orange)),
            Text(
              LearnSpeaker.numberWords[_number][0].toUpperCase() +
                  LearnSpeaker.numberWords[_number].substring(1),
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 14),
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: GridView.count(
                  crossAxisCount: 5,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    for (var i = 1; i <= _number; i++)
                      AnimatedScale(
                        scale: _highlighted == i ? 1.15 : 1,
                        duration: const Duration(milliseconds: 250),
                        child: AnimatedOpacity(
                          opacity: (_highlighted == 0 || i <= _highlighted) ? 1 : 0.25,
                          duration: const Duration(milliseconds: 250),
                          child: LearnPhoto(item: item, corner: 12),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _counting ? null : _countAloud,
                  icon: const Icon(Icons.volume_up),
                  label: const Text(
                    'Count it!',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  _stepButton(Icons.chevron_left, _number > 1, () => _change(-1)),
                  const SizedBox(width: 16),
                  _stepButton(Icons.chevron_right, _number < _maxNumber, () => _change(1)),
                ],
              ),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: _showVideo,
              icon: const Icon(Icons.smart_display),
              label: const Text(
                'Watch counting video',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------- Name lists (fruits, veg)

/// Port of `NameListView`.
class NameListScreen extends StatelessWidget {
  const NameListScreen({
    super.key,
    required this.title,
    required this.items,
    required this.color,
  });

  final String title;
  final List<LearnItem> items;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: 200,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          childAspectRatio: 0.82,
        ),
        itemCount: items.length,
        itemBuilder: (context, i) {
          final item = items[i];
          return Material(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(20),
            child: InkWell(
              borderRadius: BorderRadius.circular(20),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ItemDetailScreen(item: item, color: color),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Column(
                  children: [
                    LearnPhoto(item: item),
                    const SizedBox(height: 8),
                    Expanded(
                      child: Center(
                        child: Text(
                          item.name,
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Port of `ItemDetailView`.
class ItemDetailScreen extends StatefulWidget {
  const ItemDetailScreen({super.key, required this.item, required this.color});

  final LearnItem item;
  final Color color;

  @override
  State<ItemDetailScreen> createState() => _ItemDetailScreenState();
}

class _ItemDetailScreenState extends State<ItemDetailScreen> {
  @override
  void initState() {
    super.initState();
    LearnSpeaker.instance.say(widget.item.name);
  }

  @override
  void dispose() {
    LearnSpeaker.instance.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return Scaffold(
      appBar: AppBar(title: Text(item.name)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: LearnPhoto(item: item, corner: 28),
                ),
                const SizedBox(height: 20),
                Text(item.name, style: _big(44)),
                const SizedBox(height: 20),
                _pillButton(
                  onPressed: () => LearnSpeaker.instance.say(item.name),
                  icon: Icons.volume_up,
                  label: 'Say it',
                  color: widget.color,
                ),
                const SizedBox(height: 20),
                RemoteVideoView(
                  query: 'learn ${item.name} for toddlers',
                  knownId: item.youtubeId,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
