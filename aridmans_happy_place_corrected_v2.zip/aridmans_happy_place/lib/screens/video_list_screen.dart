import 'package:flutter/material.dart';

import '../models/learning_category.dart';
import '../services/youtube_service.dart';
import '../widgets/video_tile.dart';
import 'video_player_screen.dart';

/// Port of `VideoListView`.
class VideoListScreen extends StatefulWidget {
  const VideoListScreen({super.key, required this.category});

  final LearningCategory category;

  @override
  State<VideoListScreen> createState() => _VideoListScreenState();
}

class _VideoListScreenState extends State<VideoListScreen> {
  List<YouTubeVideo> _videos = const [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final videos = await YouTubeService.instance.search(widget.category);
      if (!mounted) return;
      setState(() => _videos = videos);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _videos = const [];
        _error = e.toString();
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _play(YouTubeVideo video) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => VideoPlayerScreen(video: video, playlist: _videos),
      ),
    );
  }

  Widget _message(IconData icon, String title, String? description) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            if (description != null) ...[
              const SizedBox(height: 8),
              Text(description, textAlign: TextAlign.center),
            ],
            const SizedBox(height: 16),
            OutlinedButton(onPressed: _load, child: const Text('Try again')),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_loading) {
      body = const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [CircularProgressIndicator(), SizedBox(height: 12), Text('Finding videos…')],
        ),
      );
    } else if (_error != null) {
      body = _message(Icons.warning_amber_rounded, "Couldn't load videos", _error);
    } else if (_videos.isEmpty) {
      body = _message(Icons.play_circle_outline, 'No videos found', 'Try again later.');
    } else {
      body = ListView.builder(
        itemCount: _videos.length,
        itemBuilder: (context, i) {
          final video = _videos[i];
          return VideoTile(video: video, onTap: () => _play(video));
        },
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(widget.category.title)),
      body: body,
    );
  }
}
