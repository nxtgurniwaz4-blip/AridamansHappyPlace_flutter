import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/youtube_service.dart';
import '../widgets/learn_widgets.dart';
import '../widgets/video_tile.dart';

/// YouTube-app style player page.
///
/// Portrait: edge-to-edge 16:9 player at the top, title + "Up next" list below.
/// Landscape on a phone: the video fills the whole screen (status bar hidden).
/// Landscape on a tablet: video on the left, "Up next" list on the right.
class VideoPlayerScreen extends StatefulWidget {
  const VideoPlayerScreen({
    super.key,
    required this.video,
    required this.playlist,
  });

  final YouTubeVideo video;
  final List<YouTubeVideo> playlist;

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  // Keeps the same player alive when the layout switches on rotation.
  final GlobalKey _playerKey = GlobalKey();
  late YouTubeVideo _current = widget.video;
  bool? _immersive;

  @override
  void dispose() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _setImmersive(bool value) {
    if (_immersive == value) return;
    _immersive = value;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      SystemChrome.setEnabledSystemUIMode(
        value ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge,
      );
    });
  }

  Widget _player() => YouTubePlayerBox(
        key: _playerKey,
        videoId: _current.id,
        autoPlay: true,
      );

  Widget _topBar() => Align(
        alignment: Alignment.centerLeft,
        child: IconButton(
          icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 32),
          onPressed: () => Navigator.of(context).pop(),
        ),
      );

  Widget _details() {
    final scheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;
    final list = widget.playlist;

    return ListView.builder(
      itemCount: list.length + 1,
      itemBuilder: (context, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _current.title,
                  style: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text(
                  _current.channelTitle,
                  style: textTheme.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
                ),
                if (list.length > 1) ...[
                  const SizedBox(height: 18),
                  Text(
                    'Up next',
                    style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ],
              ],
            ),
          );
        }
        final video = list[i - 1];
        return VideoTile(
          video: video,
          selected: video.id == _current.id,
          onTap: () => setState(() => _current = video),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final landscape = size.width > size.height;
    final tablet = size.shortestSide >= 600;

    _setImmersive(landscape && !tablet);

    // Phone, landscape: just the video, as big as it fits.
    if (landscape && !tablet) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Center(
            child: AspectRatio(aspectRatio: 16 / 9, child: _player()),
          ),
        ),
      );
    }

    // Tablet, landscape: video left, list right.
    if (landscape && tablet) {
      return Scaffold(
        body: SafeArea(
          child: Row(
            children: [
              Expanded(
                flex: 65,
                child: ColoredBox(
                  color: Colors.black,
                  child: Column(
                    children: [
                      _topBar(),
                      Expanded(
                        child: Center(
                          child: AspectRatio(aspectRatio: 16 / 9, child: _player()),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(flex: 35, child: _details()),
            ],
          ),
        ),
      );
    }

    // Portrait (phone or tablet): player on top, edge to edge.
    return Scaffold(
      body: Column(
        children: [
          ColoredBox(
            color: Colors.black,
            child: SafeArea(
              bottom: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [_topBar(), _player()],
              ),
            ),
          ),
          Expanded(child: _details()),
        ],
      ),
    );
  }
}
