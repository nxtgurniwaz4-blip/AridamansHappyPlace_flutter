import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/categories_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Follow the phone's rotation, like the YouTube app.
  await SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  runApp(const AridmansHappyPlaceApp());
}

/// Port of `AridmansHappyPlaceApp.swift`.
class AridmansHappyPlaceApp extends StatelessWidget {
  const AridmansHappyPlaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Aridman's Happy Place",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
          brightness: Brightness.dark,
        ),
      ),
      home: const CategoriesScreen(),
    );
  }
}
