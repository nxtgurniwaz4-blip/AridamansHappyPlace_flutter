/// Port of `LearningCategory` from VideoCatalog.swift.
enum LearningCategory {
  buses('Buses', 'Buses and bus videos', '🚌', 'bus buses', true),
  tractors('Tractors', 'Tractors and farming machines', '🚜', 'tractor tractors', true),
  jcbs('JCBs', 'JCB and excavator videos', '🚧', 'JCB excavator', true),
  trucks('Trucks', 'Trucks and heavy vehicles', '🚛', 'truck trucks', true),
  cars('Cars', 'Cars and vehicles', '🚗', 'car cars', true),
  farms('Farms', 'Farming and farm life', '🌾', 'farming farm', true),
  villages('Villages', 'Village life videos', '🏘️', 'Indian village life', true),
  construction('Construction', 'Construction machines', '🏗️', 'construction machines', true),
  abcd('ABCD / Alphabet', 'Learn A to Z', '🔤', 'ABC alphabet phonics for kids', false),
  counting('Counting / Numbers', 'Learn to count', '🔢', 'counting numbers 1 10 for kids', false),
  days('Days of the Week', 'Learn the days', '📅', 'days of the week names for kids', false),
  months('Months', 'Learn the months', '🗓️', 'months of the year names for kids', false),
  fruits('Fruits', 'Fruit names', '🍎', 'fruit names for kids', false),
  vegetables('Vegetables', 'Vegetable names', '🥕', 'vegetable names for kids', false);

  const LearningCategory(
    this.title,
    this.subtitle,
    this.emoji,
    this.searchQuery,
    this.usesPramodsLifeChannel,
  );

  final String title;
  final String subtitle;
  final String emoji;
  final String searchQuery;

  /// Vehicle/farm categories come only from the Pramod's Life channel.
  final bool usesPramodsLifeChannel;
}
