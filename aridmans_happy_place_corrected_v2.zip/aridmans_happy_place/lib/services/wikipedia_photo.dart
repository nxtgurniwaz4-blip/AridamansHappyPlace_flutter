import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Port of `WikipediaPhoto`: finds a lead photo for an article, no key needed.
/// Wikipedia photos are freely licensed but many need credit (e.g. CC BY-SA).
/// Fine for personal use; add credits before publishing to a store.
class WikipediaPhoto {
  // Many photos can ask for the same title at once (e.g. the counting grid).
  static final Map<String, Future<String?>> _inflight = {};

  static Future<String?> url(String title) =>
      _inflight.putIfAbsent(title, () => _lookup(title).whenComplete(() => _inflight.remove(title)));

  static Future<String?> _lookup(String title) async {
    final prefs = await SharedPreferences.getInstance();
    final cacheKey = 'learn_wiki_$title';
    final cached = prefs.getString(cacheKey);
    if (cached != null) return cached;

    final slug = Uri.encodeComponent(title.replaceAll(' ', '_'));
    final endpoint =
        Uri.parse('https://en.wikipedia.org/api/rest_v1/page/summary/$slug');
    try {
      final response = await http.get(
        endpoint,
        headers: {'User-Agent': 'AridmansHappyPlace/1.0 (Flutter app)'},
      );
      if (response.statusCode != 200) return null;
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      var source = json['thumbnail']?['source'] as String?;
      final original = json['originalimage'] as Map<String, dynamic>?;
      final width = original?['width'] as int?;
      if (original != null && width != null && width <= 1600) {
        source = original['source'] as String?;
      }
      if (source == null) return null;
      await prefs.setString(cacheKey, source);
      return source;
    } catch (_) {
      return null;
    }
  }
}
