import 'dart:io' show Platform;

import 'package:flutter_tts/flutter_tts.dart';

/// Port of `LearnSpeaker`. Uses the phone's built-in text-to-speech.
class LearnSpeaker {
  LearnSpeaker._();
  static final LearnSpeaker instance = LearnSpeaker._();

  final FlutterTts _tts = FlutterTts();
  late final Future<void> _ready = _init();

  static const numberWords = [
    'zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight',
    'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen',
    'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty',
  ];

  Future<void> _init() async {
    try {
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(0.4);
      await _tts.setPitch(1.2);
      await _tts.awaitSpeakCompletion(true);
      if (Platform.isIOS) {
        await _tts.setIosAudioCategory(
          IosTextToSpeechAudioCategory.playback,
          [IosTextToSpeechAudioCategoryOptions.mixWithOthers],
        );
      }
    } catch (_) {}
  }

  /// Speaks [text], interrupting current speech first.
  /// The returned future completes when speaking finishes.
  Future<void> say(String text) async {
    try {
      await _ready;
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
