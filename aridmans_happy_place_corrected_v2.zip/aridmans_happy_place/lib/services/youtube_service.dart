import 'dart:convert';
import 'dart:io' show Platform;

import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/learning_category.dart';

class YouTubeVideo {
  const YouTubeVideo({
    required this.id,
    required this.title,
    required this.channelTitle,
    this.thumbnailUrl,
  });

  final String id;
  final String title;
  final String channelTitle;
  final String? thumbnailUrl;
}

class YouTubeException implements Exception {
  YouTubeException(this.message);
  final String message;

  static final missingKey = YouTubeException(
    'No YouTube key in this build. Pass it with '
    '--dart-define=YOUTUBE_API_KEY=... (in Codemagic: the "youtube" variable group).',
  );

  @override
  String toString() => message;
}

/// Port of `YouTubeService` (VideoCatalog.swift) and `YouTubeAPI` (LearnViews.swift).
///
/// The key is NOT stored in Git. Supply it at build time:
///   flutter run --dart-define=YOUTUBE_API_KEY=xxxx
class YouTubeService {
  YouTubeService._();
  static final YouTubeService instance = YouTubeService._();

  static const String _apiKey = String.fromEnvironment('YOUTUBE_API_KEY');
  static const String _pramodsLifeChannelId = 'UC1V1PQT_ZVRjzuzioG05rrQ';
  static const String _endpoint = 'https://www.googleapis.com/youtube/v3/search';

  // Titles containing any of these words are hidden (same list as the iOS app).
  static const Set<String> _blockedWords = {
    'accident', 'accidents', 'crash', 'crashed', 'rescue', 'rescued', 'fire',
    'burnt', 'burning', 'dead', 'death', 'died', 'killed', 'injured', 'blood',
    'fight', 'overturned', 'drown', 'drowned', 'collision', 'flood', 'flooded',
  };

  Future<Map<String, String>> _headers() async {
    // Needed if the key is restricted to the iOS app in Google Cloud.
    final headers = <String, String>{};
    try {
      final info = await PackageInfo.fromPlatform();
      if (Platform.isIOS) {
        headers['X-Ios-Bundle-Identifier'] = info.packageName;
      }
    } catch (_) {}
    return headers;
  }

  Future<List<YouTubeVideo>> search(LearningCategory category) async {
    if (_apiKey.isEmpty) throw YouTubeException.missingKey;

    // Strictest search first, then loosen the filters if nothing comes back.
    const attempts = <({String? safeSearch, bool localized})>[
      (safeSearch: 'strict', localized: true),
      (safeSearch: 'moderate', localized: false),
      (safeSearch: null, localized: false),
    ];

    for (final attempt in attempts) {
      final params = <String, String>{
        'part': 'snippet',
        'q': category.searchQuery,
        'type': 'video',
        'maxResults': '25',
        'order': 'relevance',
        'key': _apiKey,
        if (attempt.safeSearch != null) 'safeSearch': attempt.safeSearch!,
        if (attempt.localized) 'regionCode': 'IN',
        if (attempt.localized) 'relevanceLanguage': 'en',
        if (category.usesPramodsLifeChannel) 'channelId': _pramodsLifeChannelId,
      };
      final videos = await _fetchVideos(params);
      if (videos.isNotEmpty) return videos;
    }
    return const [];
  }

  Future<List<YouTubeVideo>> _fetchVideos(Map<String, String> params) async {
    final uri = Uri.parse(_endpoint).replace(queryParameters: params);
    final response = await http.get(uri, headers: await _headers());

    if (response.statusCode < 200 || response.statusCode > 299) {
      String? message;
      try {
        message = (jsonDecode(response.body)['error']?['message']) as String?;
      } catch (_) {}
      throw YouTubeException(message ?? 'YouTube returned HTTP ${response.statusCode}.');
    }

    final items = (jsonDecode(response.body)['items'] as List?) ?? const [];
    final videos = <YouTubeVideo>[];
    for (final raw in items) {
      final item = raw as Map<String, dynamic>;
      final videoId = item['id']?['videoId'] as String?;
      if (videoId == null) continue;
      final snippet = item['snippet'] as Map<String, dynamic>;
      final title = _cleanTitle(snippet['title'] as String? ?? '');
      if (_isUnsuitable(title)) continue;
      final thumbs = snippet['thumbnails'] as Map<String, dynamic>?;
      final thumb = thumbs?['medium']?['url'] ??
          thumbs?['high']?['url'] ??
          thumbs?['default']?['url'];
      videos.add(YouTubeVideo(
        id: videoId,
        title: title,
        channelTitle: snippet['channelTitle'] as String? ?? '',
        thumbnailUrl: thumb as String?,
      ));
    }
    return videos;
  }

  static bool _isUnsuitable(String title) {
    final words = title
        .toLowerCase()
        .split(RegExp(r'[^a-z]+'))
        .where((w) => w.isNotEmpty)
        .toSet();
    return words.any(_blockedWords.contains);
  }

  static String _cleanTitle(String title) => title
      .replaceAll('&amp;', '&')
      .replaceAll('&#39;', "'")
      .replaceAll('&quot;', '"')
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>');

  /// Finds the first kid-safe video for a phrase. Cached on-device to save quota.
  Future<String> firstVideoId(String query) async {
    final prefs = await SharedPreferences.getInstance();
    final cacheKey = 'learn_yt_$query';
    final cached = prefs.getString(cacheKey);
    if (cached != null) return cached;

    if (_apiKey.isEmpty) throw YouTubeException.missingKey;

    const attempts = <({bool embeddable, String safe})>[
      (embeddable: true, safe: 'strict'),
      (embeddable: false, safe: 'strict'),
      (embeddable: false, safe: 'moderate'),
    ];

    for (final attempt in attempts) {
      final params = <String, String>{
        'part': 'snippet',
        'type': 'video',
        'safeSearch': attempt.safe,
        'maxResults': '5',
        'q': query,
        'key': _apiKey,
        if (attempt.embeddable) 'videoEmbeddable': 'true',
      };
      final uri = Uri.parse(_endpoint).replace(queryParameters: params);
      final response = await http.get(uri, headers: await _headers());
      if (response.statusCode != 200) {
        throw YouTubeException(
          'YouTube refused the request (error ${response.statusCode}). Check that '
          'YouTube Data API v3 is enabled and the key restrictions allow this app.',
        );
      }
      final items = (jsonDecode(response.body)['items'] as List?) ?? const [];
      for (final raw in items) {
        final id = raw['id']?['videoId'] as String?;
        if (id != null) {
          await prefs.setString(cacheKey, id);
          return id;
        }
      }
    }
    throw YouTubeException('No video found for this item.');
  }
}
