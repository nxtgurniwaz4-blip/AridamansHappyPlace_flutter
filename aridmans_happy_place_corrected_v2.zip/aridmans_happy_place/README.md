# Aridman's Happy Place (Flutter)

Flutter port of the SwiftUI iOS app `AridamansHappyPlace-iOS-`.
Runs on iOS and Android from one codebase.

## Setup

```bash
flutter create --org com.yourorg --project-name aridmans_happy_place .
flutter pub get
flutter run --dart-define=YOUTUBE_API_KEY=YOUR_KEY
```

Run `flutter create .` inside this folder; it only adds the `ios/` and `android/`
folders and will not overwrite `lib/` or `pubspec.yaml`.
Use the same bundle id as your existing iOS app if you want to ship it as an update.

## API key

The Swift app read `YOUTUBE_API_KEY` from Info.plist. In Flutter it comes from a
build-time define instead, so it is still never stored in Git:

```bash
flutter build ipa --dart-define=YOUTUBE_API_KEY=$YOUTUBE_API_KEY
```

If your key is restricted to an iOS bundle id in Google Cloud, the app sends the
`X-Ios-Bundle-Identifier` header on iOS exactly like the Swift version did.
For Android, either leave the key unrestricted by app or add an Android restriction
(package name + SHA-1) in Google Cloud.

## Android extras (android/app/src/main/AndroidManifest.xml)

Inside `<manifest>` add:

```xml
<uses-permission android:name="android.permission.INTERNET"/>
<queries>
  <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
</queries>
```

If the build complains about `minSdk`, set `minSdk = 24` in `android/app/build.gradle(.kts)`.

## Your own photos (optional)

Same idea as the Swift app: add `assets/learn/learn_<lowercase_name>.png`
(e.g. `learn_apple.png`, `learn_sweet_potato.png`). Anything missing falls back to Wikipedia.

## Swift -> Flutter map

| Swift file | Flutter file |
|---|---|
| AridmansHappyPlaceApp.swift | lib/main.dart |
| CategoriesView.swift, CategoryTile.swift | lib/screens/categories_screen.dart |
| VideoCatalog.swift (enum) | lib/models/learning_category.dart |
| VideoCatalog.swift (YouTubeService) + YouTubeAPI | lib/services/youtube_service.dart |
| VideoListView.swift | lib/screens/video_list_screen.dart |
| LearnViews.swift (data) | lib/models/learn_data.dart |
| LearnViews.swift (LearnSpeaker) | lib/services/speaker.dart |
| LearnViews.swift (WikipediaPhoto) | lib/services/wikipedia_photo.dart |
| LearnViews.swift (LearnPhoto, players) | lib/widgets/learn_widgets.dart |
| LearnViews.swift (screens) | lib/screens/learn_screens.dart |

## Rotation and the video player

The app follows the phone's orientation (`main.dart` allows all orientations).
Tapping a video opens a YouTube-app style page: edge-to-edge player on top in portrait,
full-screen video in landscape on phones, video + "Up next" side by side on tablets.
After `flutter create .`, check `ios/Runner/Info.plist` still lists the landscape
orientations under `UISupportedInterfaceOrientations` (the default does).


## App branding

The exact artwork supplied by the user is stored as `assets/brand/aridaman_logo.png`
and `assets/brand/app_background.png`; it is used for the launcher icon and home-screen
background. After installing dependencies, generate the native Android and iOS
launcher icons with:

```bash
dart run flutter_launcher_icons
```

The category home screen uses the same artwork as a soft full-screen background
with the logo displayed at the top.
